#pragma once
#include <glm/glm.hpp>
struct GameState;
class Entity
{
public:
	Entity();
	Entity(GameState* _gm);
	~Entity();
	void movement();
	glm::vec3 GetModelMax(glm::vec3);
	glm::vec3 GetModelMin(glm::vec3);
	bool GetCollision(glm::vec3 PlayerModelMax, glm::vec3 PlayerModelMin, glm::vec3 CubeModelMax, glm::vec3 CubeModelMin);

	glm::vec3 campos;
	float camangle = 0.0f;
private:
	GameState* GM;
	glm::vec3 CubeModelMax;
	glm::vec3 CubeModelMin;
	
};

