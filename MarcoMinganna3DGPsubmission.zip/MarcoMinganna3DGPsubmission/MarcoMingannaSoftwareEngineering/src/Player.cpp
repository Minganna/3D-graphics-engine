#include "Player.h"
#include "Entity.h"
#include "ShaderProgram.h"
#include "VertexArray.h"
#include "Texture.h"
#include "RenderTexture.h"


#include <SDL2/SDL.h>
#include <GL/glew.h>
#include <glm/ext.hpp>

#include <exception>

Player::Player()
{
}

Player::Player(GameState* _gm) : Entity(_gm)
{
	shape = new VertexArray("../Ryuji_Sakamoto.obj");
	texture = new Texture("../sd_pc015_t01.png");
	campos = glm::vec3(0.0f, 0.0f, 0.0f);
	angle = 180;
}

void Player::createCamera(ShaderProgram *shader)
{
	glm::mat4 model(1.0f);
	model = glm::translate(model, campos);
	model = glm::rotate(model, glm::radians(camangle), glm::vec3(0, 1, 0));
	shader->setUniform("in_View", glm::inverse(model));

}

void Player::DrawPlayer(RenderTexture *rt, ShaderProgram *shader)
{

	glm::mat4 model = glm::mat4(1.0f);

	glm::mat4 t(1.0f);
	// rotate it by angle (the camera�s Y rotation)
	t = glm::rotate(t, glm::radians(camangle), glm::vec3(0, 1, 0));
	// move forward 1 unit
	t = glm::translate(t, glm::vec3(0, 0, -0.01f));
	// apply to an initial position
	glm::vec3 fwd = t * glm::vec4(0.0f, 0.0f, 0.0f, 0.1f);
	// normalize to get the unit vector
	fwd = glm::normalize(fwd);

	model = glm::translate(model, (campos - (-10.0f * fwd + glm::vec3(0.0f, 7.1f, 0.0f))));
	PlayerPos = (campos - (-10.0f * fwd + glm::vec3(0.0f, 7.1f, 0.0f)));
	model = glm::rotate(model, glm::radians(camangle), glm::vec3(0, 1, 0));
	model = glm::rotate(model, glm::radians(angle), glm::vec3(0, 1, 0));
	model = glm::scale(model, glm::vec3(0.05f, 0.05f, 0.05f));
	shader->setUniform("in_Model", model);
	shader->setUniform("in_Texture", texture);
	shader->draw(rt, shape);

}

glm::vec3 Player::GetPlayerPos()
{
	return PlayerPos;
}

//campos 


Player::~Player()
{
}
