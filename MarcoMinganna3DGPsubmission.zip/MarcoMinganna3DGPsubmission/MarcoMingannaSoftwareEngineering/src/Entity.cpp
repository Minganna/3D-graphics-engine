#include "Entity.h"
#include "ShaderProgram.h"
#include "VertexArray.h"
#include "Texture.h"
#include "GameState.h"


#include <SDL2/SDL.h>
#include <GL/glew.h>
#include <glm/ext.hpp>

#include <exception>
#include <iostream>

Entity::Entity()
{

}

Entity::Entity(GameState* _gm)
{
	GM = _gm;
}


Entity::~Entity()
{
}

void Entity::movement()
{
	if (GM->keyLeft)
	{
		camangle += 1.0f;
	}
	else if (GM->keyRight)
	{
		camangle -= 1.0f;
	}
	if (GM->keyUp)
	{
		glm::mat4 t(1.0f);
		// rotate it by angle (the camera�s Y rotation)
		t = glm::rotate(t, glm::radians(camangle), glm::vec3(0, 1, 0));
		// move forward 1 unit
		t = glm::translate(t, glm::vec3(0, 0, -0.01f));
		// apply to an initial position
		glm::vec3 fwd = t * glm::vec4(0.0f, 0.0f, 0.0f, 0.1f);
		// normalize to get the unit vector
		fwd = glm::normalize(fwd);
		campos += fwd;
	}
	if (GM->keyDown)
	{
		glm::mat4 t(1.0f);
		// rotate it by angle (the camera�s Y rotation)
		t = glm::rotate(t, glm::radians(camangle), glm::vec3(0, 1, 0));
		// move forward 1 unit
		t = glm::translate(t, glm::vec3(0, 0, -0.01f));
		// apply to an initial position
		glm::vec3 fwd = t * glm::vec4(0.0f, 0.0f, 0.0f, 0.1f);
		// normalize to get the unit vector
		fwd = glm::normalize(fwd);
		campos -= fwd;
	}
}

glm::vec3 Entity::GetModelMax(glm::vec3 CubeModel)
{
	CubeModelMax = glm::vec3(CubeModel.x + 10, CubeModel.y + 10, CubeModel.z + 10);
	return CubeModelMax;
}
 
glm::vec3 Entity::GetModelMin(glm::vec3 CubeModel)
{
	CubeModelMin = glm::vec3(CubeModel.x - 10, CubeModel.y - 10, CubeModel.z - 10);
	return CubeModelMin;
}

bool Entity::GetCollision(glm::vec3 PlayerModelMax, glm::vec3 PlayerModelMin, glm::vec3 CubeModelMax, glm::vec3 CubeModelMin)
{

	
	if (PlayerModelMax.x < CubeModelMin.x)
	{

		std::cout << "collisionDetected";
	}
	if (PlayerModelMin.x > CubeModelMax.x)
	{

		std::cout << "collisionDetected";

	}
	if (PlayerModelMax.y < CubeModelMin.y)
	{

		std::cout << "collisionDetected";
	}
	if (PlayerModelMin.y> CubeModelMax.y)
	{

		std::cout << "collisionDetected";
	}
	if (PlayerModelMax.z < CubeModelMin.z)
	{

		std::cout << "collisionDetected";
	}
	if (PlayerModelMin.z > CubeModelMax.z)
	{

		std::cout << "collisionDetected";
	}


	
	return false;
}
