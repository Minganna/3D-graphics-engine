#include "Game.h"
#include "VertexBuffer.h"
#include "VertexArray.h"
#include "ShaderProgram.h"
#include "Texture.h"
#include "Player.h"
#include "GameState.h"
#include "RenderTexture.h"




#include <SDL2/SDL.h>
#include <GL/glew.h>
#include <glm/ext.hpp>

#include <exception>

int windowWidth = 800;
int windowHeight = 600;

SDL_Window *CreateWindows();

Game::Game()
{
	float angle = 0;
	GameState GM;
	SDL_Window *window = CreateWindows();
	VertexArray *hallShape = new VertexArray("../re_hall_baked.obj");
	Texture *hallTexture = new Texture("../re_hall_diffuse.png");
	Player * cat = new Player(&GM);
	VertexArray *ProfLayton = new VertexArray("../G_Layton.obj");
	Texture *ProfTexture = new Texture("../layton_GOLD_01.png");
	ShaderProgram *shader = new ShaderProgram("../simple.vert", "../simple.frag");
	ShaderProgram *Hallshader = new ShaderProgram("../Hall.vert", "../Hall.frag");
	ShaderProgram *ToonShader = new ShaderProgram("../Toon.vert", "../Toon.frag");
	ShaderProgram *FlatShader = new ShaderProgram("../Flat.vert", "../Flat.frag");
	ShaderProgram *lightkeyShader = new ShaderProgram("../lightkeypass.vert", "../lightkeypass.frag");
	ShaderProgram *nullShader = new ShaderProgram("../nullpass.vert", "../nullpass.frag");
	ShaderProgram *blurShader = new ShaderProgram("../blur.vert", "../blur.frag");
	ShaderProgram *mergeShader = new ShaderProgram("../mergepass.vert", "../mergepass.frag");
	RenderTexture *rt = new RenderTexture(512, 512);
	RenderTexture *lightkeyRt = new RenderTexture(512, 512);
	RenderTexture *blurRt = new RenderTexture(512, 512);
	RenderTexture *blur2Rt = new RenderTexture(512, 512);
	RenderTexture *blur3Rt = new RenderTexture(512, 512);
	RenderTexture *mergeRt = new RenderTexture(512, 512);

	glm::vec3 PlayerPos;

	bool quit = false;

	glEnable(GL_CULL_FACE);

	while (!quit)
	{
		SDL_Event event = { 0 };

		while (SDL_PollEvent(&event))
		{
			if (event.type == SDL_QUIT || event.key.keysym.sym == SDLK_ESCAPE)
			{
				quit = true;
			}
			else if (event.type == SDL_KEYDOWN)
			{
				switch (event.key.keysym.sym)
				{
				case SDLK_LEFT:
					GM.keyLeft = true;
					break;
				case SDLK_RIGHT:
					GM.keyRight = true;
					break;
				case SDLK_UP:
					GM.keyUp = true;
					break;
				case SDLK_DOWN:
					GM.keyDown = true;
					break;
				case SDLK_BACKSLASH:
					GM.Bloom = true;
					break;
				default:
					break;
				}
			}
			else if (event.type == SDL_KEYUP)
			{
				switch (event.key.keysym.sym)
				{
				case SDLK_LEFT:
					GM.keyLeft = false;
					break;
				case SDLK_RIGHT:
					GM.keyRight = false;
					break;
				case SDLK_UP:
					GM.keyUp = false;
					break;
				case SDLK_DOWN:
					GM.keyDown = false;
					break;
				case SDLK_BACKSLASH:
					GM.Bloom = false;
					break;
				default:
					break;
				}

			}
		}


		glEnable(GL_DEPTH_TEST);
		rt->clear();

		SDL_GetWindowSize(window, &windowWidth, &windowHeight);
		glViewport(0, 0, windowWidth, windowHeight);
		glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

		/*
		 * Draw with perspective projection matrix
		 */

			shader->setUniform("in_Projection", glm::perspective(glm::radians(45.0f),
				(float)windowWidth / (float)windowHeight, 0.1f, 100.f));
			shader->setUniform("in_Emissive", glm::vec3(0, 0, 0));
			shader->setUniform("in_Ambient", glm::vec3(0.2, 0.2, 0.2));
			shader->setUniform("in_LightPos", glm::vec3(50, 10, 10));

			Hallshader->setUniform("in_Projection", glm::perspective(glm::radians(45.0f),
				(float)windowWidth / (float)windowHeight, 0.1f, 100.f));
			
			ToonShader->setUniform("in_Projection", glm::perspective(glm::radians(45.0f),
				(float)windowWidth / (float)windowHeight, 0.1f, 100.f));
			ToonShader->setUniform("in_Emissive", glm::vec3(0, 0, 0));
			ToonShader->setUniform("in_Ambient", glm::vec3(0.2, 0.2, 0.2));
			ToonShader->setUniform("in_LightPos", glm::vec3(50, 10, 10));

			FlatShader->setUniform("in_Projection", glm::perspective(glm::radians(45.0f),
				(float)windowWidth / (float)windowHeight, 0.1f, 100.f));
			FlatShader->setUniform("in_Emissive", glm::vec3(0, 0, 0));
			FlatShader->setUniform("in_Ambient", glm::vec3(0.2, 0.2, 0.2));
			FlatShader->setUniform("in_LightPos", glm::vec3(50, 10, 10));

		// create arbitary matrix

		cat->movement();
	

		// Create a "camera"
		cat->createCamera(Hallshader);
		cat->createCamera(ToonShader);
		cat->createCamera(FlatShader);
		cat->createCamera(shader);





		// Draw the mansion
		glm::mat4 model(1.0f);
		//Hallshader->setUniform("in_View", glm::inverse(model));
		model = glm::mat4(1.0f);
		model = glm::translate(model, glm::vec3(2.0f, -2.0f, -16.0f));
		model = glm::rotate(model, glm::radians(90.0f), glm::vec3(0, 1, 0));
		Hallshader->setUniform("in_Model", model);
		Hallshader->setUniform("in_Texture", hallTexture);
		Hallshader->draw(rt, hallShape);
		


		// Draw the profLayton
	
		model = glm::mat4(1.0f);
		model = glm::translate(model, glm::vec3(2.0f, -4.5f, -16.0f));
		model = glm::rotate(model, glm::radians(angle), glm::vec3(0, 1, 0));
		model = glm::scale(model, glm::vec3(0.7f, 0.7f, 0.7f));
		if (GM.Bloom == true)
		{
			FlatShader->setUniform("in_Model", model);
			FlatShader->setUniform("in_Texture", ProfTexture);
			FlatShader->draw(rt, ProfLayton);
		}
		else
		{
			shader->setUniform("in_Model", model);
			shader->setUniform("in_Texture", ProfTexture);
			shader->draw(rt, ProfLayton);
		}
		angle += 0.1f;
		// Draw the cat
		if (GM.Bloom == true)
		{
			cat->DrawPlayer(rt, ToonShader);
		}
		else
		{
			cat->DrawPlayer(rt, shader);
		}
		
		PlayerPos = cat->GetPlayerPos();
		PlayerModelMax=cat->GetModelMax(PlayerPos);
		PlayerModelMin=cat->GetModelMin(PlayerPos);
		CubeModelMax=cat->GetModelMax(glm::vec3(2.0f, -4.5f, -16.0f));
		CubeModelMin=cat->GetModelMin(glm::vec3(2.0f, -4.5f, -16.0f));

		cat->GetCollision(PlayerModelMax, PlayerModelMin, CubeModelMax, CubeModelMin);


		glDisable(GL_DEPTH_TEST);
		glClearColor(0.0f, 0.0f, 1.0f, 1.0f);
		glClear(GL_COLOR_BUFFER_BIT);

		lightkeyShader->setUniform("in_Texture", rt);
		lightkeyShader->draw(lightkeyRt);

		blurShader->setUniform("in_Texture", lightkeyRt);
		blurShader->draw(blurRt);

		blurShader->setUniform("in_Texture", blurRt);
		blurShader->draw(blur2Rt);

		blurShader->setUniform("in_Texture", blur2Rt);
		blurShader->draw(blur3Rt);

		mergeShader->setUniform("in_TextureA", rt);
		mergeShader->setUniform("in_TextureB", blur3Rt);
		mergeShader->draw(mergeRt);
		if (GM.Bloom==true)
		{
			nullShader->setViewport(glm::vec4(0, 0, windowWidth, windowHeight));
			nullShader->setUniform("in_Texture", mergeRt);
			nullShader->draw();
		}
		else
		{
			nullShader->setViewport(glm::vec4(0, 0, windowWidth, windowHeight));
			nullShader->setUniform("in_Texture", rt);
			nullShader->draw();
		}
	

		SDL_GL_SwapWindow(window);
	}

	SDL_DestroyWindow(window);
	SDL_Quit();

}

Game::~Game()
{
}

SDL_Window *CreateWindows()
{
	if (SDL_Init(SDL_INIT_VIDEO) < 0)
	{
		throw std::exception();
	}

	SDL_Window *window = SDL_CreateWindow("3D Graphics Assessment",
		SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED,
		windowWidth, windowHeight,
		SDL_WINDOW_RESIZABLE | SDL_WINDOW_OPENGL);

	if (!SDL_GL_CreateContext(window))
	{
		throw std::exception();
	}

	if (glewInit() != GLEW_OK)
	{
		throw std::exception();
	}
	return window;
}


