#pragma once

#include<iostream>

#include <SDL2/SDL.h>
#include <GL/glew.h>
#include <glm/ext.hpp>

#include <exception>
class Game
{
public:

	Game();
	~Game();
	glm::vec3 PlayerModelMax;
	glm::vec3 PlayerModelMin;
	glm::vec3 CubeModelMax;
	glm::vec3 CubeModelMin;
};

