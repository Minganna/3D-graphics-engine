#pragma once
struct GameState
{
	bool keyUp = false;
	bool keyRight = false;
	bool keyLeft = false;
	bool keyDown = false;
	bool Bloom = false;
};