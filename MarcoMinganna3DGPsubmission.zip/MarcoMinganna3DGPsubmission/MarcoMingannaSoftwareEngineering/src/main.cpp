#include "Game.h"




int main(int argc, char *argv[])
{
	Game *mainGame= new Game();
  return 0;
}
