#pragma once
#include "Entity.h"
#include <SDL2/SDL.h>
#include <GL/glew.h>
#include <glm/ext.hpp>

#include <exception>


class Texture;
class RenderTexture;
class VertexArray;
class ShaderProgram;
class Entity;

class Player : public Entity
{
public:
	Player();
	Player(GameState* _gm);
	void createCamera(ShaderProgram *shader);
	void DrawPlayer(RenderTexture *rt, ShaderProgram *shader);
	glm::vec3 GetPlayerPos();
	~Player();
private:
	Texture *texture;
	VertexArray *shape;
	float angle;
	glm::vec3 PlayerPos;

};

